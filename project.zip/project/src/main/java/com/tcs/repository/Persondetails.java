package com.tcs.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.tcs.domain.detail;

@Repository
public interface Persondetails  extends CrudRepository<detail,String>{

	public List<detail> findAll();

	public detail findBypartnumber(String partnumber);
	
	List<detail> findBykeyname(String keyname);
}

