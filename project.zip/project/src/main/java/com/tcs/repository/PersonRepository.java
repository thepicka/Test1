package com.tcs.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.tcs.domain.dummy;

@Repository
public interface PersonRepository  extends CrudRepository<dummy,String>{

	public List<dummy> findAll();

	public dummy findOne(String name);
	
	List<dummy> findByname(String name);
}

