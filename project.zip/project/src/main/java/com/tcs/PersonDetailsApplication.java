package com.tcs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PersonDetailsApplication {

	public static void main(String[] args) {
		SpringApplication.run(PersonDetailsApplication.class, args);
	}
}
