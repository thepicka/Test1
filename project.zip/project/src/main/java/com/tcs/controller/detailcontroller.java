package com.tcs.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.inject.Inject;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.tcs.domain.dummy;
import com.tcs.domain.detail;
import com.tcs.repository.PersonRepository;
import com.tcs.repository.Persondetails;
@RestController
public class detailcontroller {

	@Inject
	Persondetails persondetails ;
	@CrossOrigin
	@RequestMapping("/detail")
	public List<detail> getAlldetail() {
		List<detail> persons = persondetails.findAll();
		return persons;
	}
	@CrossOrigin
	@RequestMapping("/detail/{keyname}")
	public List<detail> getdetail(@PathVariable String keyname) {
		List<detail> person = persondetails.findBykeyname(keyname);
	
		return person;
	}
	
	@CrossOrigin
	@RequestMapping("/fulldetail/{partnumber}")
	public detail getpartnumber(@PathVariable String partnumber) {
		detail details = persondetails.findBypartnumber(partnumber);;
	
		return details;
	}
	
}
	
	
	
	
	