package com.tcs.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.inject.Inject;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.tcs.domain.dummy;
import com.tcs.domain.detail;
import com.tcs.repository.PersonRepository;
import com.tcs.repository.Persondetails;
@RestController
public class PersonContoller {

	@Inject
	PersonRepository personRepository;
	
	@CrossOrigin
	@RequestMapping("/persons")
	public List<dummy> getAllPerson() {
		List<dummy> persons = personRepository.findAll();
		return persons;
	}
	@CrossOrigin
	@RequestMapping("/persons/{name}")
	public List<dummy> getPerson(@PathVariable String name) {
		List<dummy> person = personRepository.findByname(name);
	
		return person;
	}
	
	
	
}
	
	
	
	
	