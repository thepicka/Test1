package com.tcs.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
public class detail {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	
	@Column(name = "partnumber", nullable = false)
	String partnumber;

	@Column(name = "partname", nullable = false)
	String partname;
	
	@Column(name = "keyname", nullable = false)
	
	String keyname;
	
	@Column(name = "owning_User", nullable = false)
	String owning_User;
	
	@Column(name = "status", nullable = false)
	String status;
	
	@Column(name = "revision", nullable = false)
	String revision;
	
	@Column(name = "last_updated", nullable = false)
	Date last_updated;
	
	@Column(name = "Type", nullable = false)
	String Type;
	
	@Column(name = "key_ch", nullable = false)
	String key_ch;
	
	@Column(name = "use", nullable = false)
	String use;
	
	@Column(name = "location", nullable = false)
	String location;
	
	@Column(name = "instance", nullable = false)
	String instance;
	
	@Column(name = "version", nullable = false)
	String version;
	
	
	/**
	 * 
	 */
	public String getpartnumber() {
		return partnumber;
	}

	public void setpartnumber(String partnumber) {
		this.partnumber = partnumber;
	}
	
	

	public String getpartname() {
		return partname;
	}

	public void setname(String partname) {
		this.partname = partname;
	}

	public String getkeyname() {
		return keyname;
	}

	public void setkeyname(String keyname) {
		this.keyname = keyname;
	}

	public String getowning_User() {
		return owning_User;
	}

	public void setowning_User(String owning_User) {
		this.owning_User = owning_User;
	}
	
	public String getstatus() {
		return status;
	}

	public void setstatus(String status) {
		this.status = status;
	}
	
	public String getrevision() {
		return revision;
	}

	public void setrevision(String revision) {
		this.revision = revision;
	}
	
	public Date getlast_updated() {
		return last_updated;
	}

	public void setlast_updated(Date last_updated) {
		this.last_updated = last_updated;
	}
	
	public String getType() {
		return Type;
	}

	public void setType(String Type) {
		this.Type = Type;
	}
	
	public String getkey_ch() {
		return key_ch;
	}

	public void setkey_ch(String key_ch) {
		this.key_ch = key_ch;
	}
	public String getuse() {
		return use;
	}

	public void setuse(String use) {
		this.use = use;
	}
	
	public String getlocation() {
		return location;
	}

	public void setlocation(String location) {
		this.location = location;
	}
	public String geinstance() {
		return instance;
	}

	public void setinstance(String instance) {
		this.instance = instance;
	}
	
	public String geversion() {
		return version;
	}

	public void setversion(String version) {
		this.version = version;
	}
	public detail(String partnumber,String partname, String keyname,String owning_User, String status, String revision, Date last_updated, String Type,String key_ch, String use, String location, String instance,String version ) {
		this.partnumber=partnumber;
		this.partname = partname;
		this.keyname = keyname;
		this.owning_User = owning_User;
		this.status=status;
		this.revision = revision;
		this.last_updated = last_updated;
		this.Type = Type;
		this.key_ch = key_ch;
		this.use=use;
		this.location = location;
		this.instance = instance;
		this.version = version;
	}

	public detail() {
	}

	
}
