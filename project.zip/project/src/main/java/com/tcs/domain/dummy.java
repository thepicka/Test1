package com.tcs.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
public class dummy {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	
	@Column(name = "id", nullable = false)
	int id;

	@Column(name = "name", nullable = false)
	String name;
	
	@Column(name = "keyname", nullable = false)
	
	String keyname;
	
	@Column(name = "keyvalue", nullable = false)
	int keyvalue;
	/**
	 * 
	 */
	public int getid() {
		return id;
	}

	public void setid(int id) {
		this.id = id;
	}
	
	

	public String getname() {
		return name;
	}

	public void setname(String name) {
		this.name = name;
	}

	public String getkeyname() {
		return keyname;
	}

	public void setkeyname(String keyname) {
		this.keyname = keyname;
	}

	public int getkeyvalue() {
		return keyvalue;
	}

	public void setkeyvalue(int keyvalue) {
		this.keyvalue = keyvalue;
	}
	

	
	public dummy(int id, String name,String keyname, int keyvalue) {
		this.id=id;
		this.name = name;
		this.keyname = keyname;
		this.keyvalue = keyvalue;
		
	}

	public dummy() {
	}

	
}
